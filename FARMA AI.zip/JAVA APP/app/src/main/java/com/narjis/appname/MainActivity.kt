package com.narjis.appname

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.CalendarContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.narjis.appname.ui.theme.STUDENTAPPTheme
import kotlinx.coroutines.launch
import java.util.*

enum class AppLanguage { ENGLISH, KANNADA }

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private var currentLanguage = mutableStateOf(AppLanguage.ENGLISH)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        tts = TextToSpeech(this, this)
        
        setContent {
            STUDENTAPPTheme {
                MainAppContainer(
                    selectedLanguage = currentLanguage.value,
                    onLanguageChange = { lang -> 
                        currentLanguage.value = lang
                        updateTtsLanguage(lang)
                    },
                    onSpeak = { text -> speak(text) },
                    startListening = { onResult -> startListening(onResult) }
                )
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            updateTtsLanguage(currentLanguage.value)
        }
    }

    private fun updateTtsLanguage(lang: AppLanguage) {
        val locale = if (lang == AppLanguage.KANNADA) Locale("kn", "IN") else Locale.ENGLISH
        val result = tts.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(this, "Language not supported for Voice", Toast.LENGTH_SHORT).show()
        }
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    private fun startListening(onResult: (String) -> Unit) {
        val lang = currentLanguage.value
        val locale = if (lang == AppLanguage.KANNADA) Locale("kn", "IN") else Locale.ENGLISH
        
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale.toString())
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, locale.toString())
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, locale.toString())
        }
        
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                Toast.makeText(this@MainActivity, "Error listening: $error", Toast.LENGTH_SHORT).show()
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    onResult(matches[0])
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        speechRecognizer?.startListening(intent)
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}

enum class Screen { Assistant, Marketplace, Weather, Chat, Schemes, Expenses, Calendar }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContainer(
    selectedLanguage: AppLanguage,
    onLanguageChange: (AppLanguage) -> Unit,
    onSpeak: (String) -> Unit, 
    startListening: ((String) -> Unit) -> Unit
) {
    var currentScreen by remember { mutableStateOf(Screen.Assistant) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Spacer(Modifier.height(12.dp))
                Text("Farmer Pro", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                HorizontalDivider()
                NavigationDrawerItem(
                    label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "AI ಸಹಾಯಕ" else "AI Assistant") },
                    selected = currentScreen == Screen.Assistant,
                    onClick = { currentScreen = Screen.Assistant; scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Default.SmartToy, null) }
                )
                NavigationDrawerItem(
                    label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಮಾರುಕಟ್ಟೆ" else "Marketplace") },
                    selected = currentScreen == Screen.Marketplace,
                    onClick = { currentScreen = Screen.Marketplace; scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Default.Storefront, null) }
                )
                NavigationDrawerItem(
                    label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಹವಾಮಾನ ವರದಿ" else "Weather Forecast") },
                    selected = currentScreen == Screen.Weather,
                    onClick = { currentScreen = Screen.Weather; scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Default.WbSunny, null) }
                )
                NavigationDrawerItem(
                    label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಸರ್ಕಾರಿ ಯೋಜನೆಗಳು" else "Govt. Schemes") },
                    selected = currentScreen == Screen.Schemes,
                    onClick = { currentScreen = Screen.Schemes; scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Default.AccountBalance, null) }
                )
                NavigationDrawerItem(
                    label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ವೆಚ್ಚ ಟ್ರ್ಯಾಕರ್" else "Expense Tracker") },
                    selected = currentScreen == Screen.Expenses,
                    onClick = { currentScreen = Screen.Expenses; scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Default.Payments, null) }
                )
                NavigationDrawerItem(
                    label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಕೃಷಿ ಕ್ಯಾಲೆಂಡರ್" else "Farming Calendar") },
                    selected = currentScreen == Screen.Calendar,
                    onClick = { currentScreen = Screen.Calendar; scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Default.CalendarToday, null) }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text(currentScreen.name, fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu")
                        }
                    },
                    actions = {
                        var showLangMenu by remember { mutableStateOf(false) }
                        IconButton(onClick = { showLangMenu = true }) {
                            Icon(Icons.Default.Language, contentDescription = "Change Language")
                        }
                        DropdownMenu(expanded = showLangMenu, onDismissRequest = { showLangMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("English") },
                                onClick = { onLanguageChange(AppLanguage.ENGLISH); showLangMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("ಕನ್ನಡ") },
                                onClick = { onLanguageChange(AppLanguage.KANNADA); showLangMenu = false }
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = currentScreen == Screen.Assistant,
                        onClick = { currentScreen = Screen.Assistant },
                        icon = { Icon(Icons.Default.SmartToy, null) },
                        label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಸ್ಕ್ಯಾನ್" else "Scan", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = currentScreen == Screen.Marketplace,
                        onClick = { currentScreen = Screen.Marketplace },
                        icon = { Icon(Icons.Default.Storefront, null) },
                        label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಮಾರುಕಟ್ಟೆ" else "Market", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = currentScreen == Screen.Calendar,
                        onClick = { currentScreen = Screen.Calendar },
                        icon = { Icon(Icons.Default.CalendarMonth, null) },
                        label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಯೋಜನೆ" else "Planner", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = currentScreen == Screen.Expenses,
                        onClick = { currentScreen = Screen.Expenses },
                        icon = { Icon(Icons.Default.Payments, null) },
                        label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಹಣಕಾಸು" else "Finance", fontSize = 10.sp) }
                    )
                }
            }
        ) { paddingValues ->
            Box(modifier = Modifier.padding(paddingValues)) {
                when (currentScreen) {
                    Screen.Assistant -> FarmerAssistantScreen(selectedLanguage, onSpeak, startListening)
                    Screen.Marketplace -> MarketplaceScreen(selectedLanguage)
                    Screen.Weather -> WeatherScreen(selectedLanguage)
                    Screen.Chat -> ChatListScreen()
                    Screen.Schemes -> SchemesScreen(selectedLanguage)
                    Screen.Expenses -> ExpensesScreen(selectedLanguage)
                    Screen.Calendar -> FarmingCalendarScreen(selectedLanguage)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmerAssistantScreen(
    selectedLanguage: AppLanguage,
    onSpeak: (String) -> Unit, 
    startListening: ((String) -> Unit) -> Unit
) {
    var capturedImage by remember { mutableStateOf<Bitmap?>(null) }
    var aiResult by remember { mutableStateOf<AIResult?>(null) }
    var voiceInput by remember { mutableStateOf("") }
    
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            capturedImage = bitmap
            analyzeImage(bitmap) { result ->
                aiResult = result
                val response = if (selectedLanguage == AppLanguage.KANNADA) {
                    "ವಿಶ್ಲೇಷಣೆ ಪೂರ್ಣಗೊಂಡಿದೆ. ${result.disease_kn} ಕಂಡುಬಂದಿದೆ. ${result.fertilizer_kn}"
                } else {
                    "Analysis complete. I found ${result.disease}. ${result.fertilizer}"
                }
                onSpeak(response)
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            cameraLauncher.launch()
        } else {
            Toast.makeText(context, "Camera permission is required to scan crops", Toast.LENGTH_LONG).show()
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { _ ->
        Toast.makeText(context, "Image selected from gallery", Toast.LENGTH_SHORT).show()
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (capturedImage != null) {
                        Image(
                            bitmap = capturedImage!!.asImageBitmap(),
                            contentDescription = "Crop Image",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(16.dp)),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .background(Color.LightGray.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.CloudUpload, 
                                    contentDescription = null, 
                                    modifier = Modifier.size(48.dp), 
                                    tint = Color.Gray
                                )
                                Text(
                                    if (selectedLanguage == AppLanguage.KANNADA) "AI ಸ್ಕ್ಯಾನ್ ಗಾಗಿ ಫೋಟೋ ಅಪ್ ಲೋಡ್ ಮಾಡಿ" else "Upload Crop Photo for AI Scan", 
                                    color = Color.Gray
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (selectedLanguage == AppLanguage.KANNADA) "ಕ್ಯಾಮೆರಾ" else "Camera")
                        }
                        OutlinedButton(
                            onClick = { galleryLauncher.launch("image/*") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (selectedLanguage == AppLanguage.KANNADA) "ಗ್ಯಾಲರಿ" else "Gallery")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (aiResult != null) {
                ResultCard(selectedLanguage, aiResult!!)
            } else if (voiceInput.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "${if (selectedLanguage == AppLanguage.KANNADA) "ನೀವು ಹೇಳಿದ್ದು" else "You said"}: \"$voiceInput\"",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
        
        FloatingActionButton(
            onClick = {
                onSpeak(if (selectedLanguage == AppLanguage.KANNADA) "ನಿಮಗೆ ಇಂದು ಹೇಗೆ ಸಹಾಯ ಮಾಡಲಿ?" else "How can I help you today?")
                startListening { result ->
                    voiceInput = result
                    handleVoiceCommand(selectedLanguage, result, onSpeak)
                }
            },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            shape = CircleShape
        ) {
            Icon(Icons.Default.Mic, contentDescription = "Voice Assistant", tint = Color.White)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MarketplaceScreen(selectedLanguage: AppLanguage) {
    var showSellDialog by remember { mutableStateOf(false) }
    var selectedMarketTab by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    
    val otherItems = remember {
        mutableStateListOf(
            MarketItem("Wheat", "₹2,200/quintal", "High quality, organic", "Nagpur"),
            MarketItem("Rice (Basmati)", "₹4,500/quintal", "Aromatic, long grain", "Punjab"),
            MarketItem("Cotton", "₹6,800/quintal", "Best grade cotton", "Gujarat"),
            MarketItem("Sugarcane", "₹3,100/ton", "Freshly harvested", "Maharashtra"),
            MarketItem("Potatoes", "₹1,200/quintal", "Bulk quantity available", "UP")
        )
    }

    val myItems = remember { mutableStateListOf<MarketItem>() }
    val soldItems = remember { mutableStateListOf<MarketItem>() }

    if (showSellDialog) {
        SellCropDialog(
            selectedLanguage = selectedLanguage,
            onDismiss = { showSellDialog = false },
            onConfirm = { name, price, loc ->
                myItems.add(0, MarketItem(name, "₹$price", "My fresh harvest", loc, isMine = true))
                showSellDialog = false
                Toast.makeText(context, if (selectedLanguage == AppLanguage.KANNADA) "ಬೆಳೆ ಯಶಸ್ವಿಯಾಗಿ ಪಟ್ಟಿಯಾಗಿದೆ!" else "Crop listed successfully!", Toast.LENGTH_SHORT).show()
                selectedMarketTab = 1
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedMarketTab) {
            Tab(selected = selectedMarketTab == 0, onClick = { selectedMarketTab = 0 }, text = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಮಾರುಕಟ್ಟೆ" else "Market") })
            Tab(selected = selectedMarketTab == 1, onClick = { selectedMarketTab = 1 }, text = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ನನ್ನ ಜಾಹೀರಾತುಗಳು" else "My Ads") })
        }

        Box(modifier = Modifier.fillMaxSize()) {
            when (selectedMarketTab) {
                0 -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text(if (selectedLanguage == AppLanguage.KANNADA) "ಹತ್ತಿರದ ಬೆಳೆಗಳು" else "Crops Available Nearby", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        items(otherItems) { item ->
                            MarketCard(
                                selectedLanguage = selectedLanguage,
                                item = item,
                                onBuy = {
                                    Toast.makeText(context, if (selectedLanguage == AppLanguage.KANNADA) "ಬೇಡಿಕೆ ಕಳುಹಿಸಲಾಗಿದೆ!" else "Order request sent!", Toast.LENGTH_LONG).show()
                                }
                            )
                        }
                    }
                }
                1 -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (myItems.isNotEmpty()) {
                            item {
                                Text(if (selectedLanguage == AppLanguage.KANNADA) "ಸಕ್ರಿಯ ಪಟ್ಟಿಗಳು" else "Active Listings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                            items(myItems) { item ->
                                MarketCard(
                                    selectedLanguage = selectedLanguage,
                                    item = item,
                                    onMarkAsSold = {
                                        myItems.remove(item)
                                        soldItems.add(0, item.copy(isSold = true))
                                    },
                                    onDelete = { myItems.remove(item) }
                                )
                            }
                        }
                        if (soldItems.isNotEmpty()) {
                            item {
                                Spacer(modifier = Modifier.height(24.dp))
                                Text(if (selectedLanguage == AppLanguage.KANNADA) "ಮಾರಾಟವಾದ ಇತಿಹಾಸ" else "Sold History", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                            items(soldItems) { item ->
                                MarketCard(selectedLanguage = selectedLanguage, item = item)
                            }
                        }
                        if (myItems.isEmpty() && soldItems.isEmpty()) {
                            item {
                                Box(modifier = Modifier.fillParentMaxSize(), contentAlignment = Alignment.Center) {
                                    Text(if (selectedLanguage == AppLanguage.KANNADA) "ನೀವು ಇನ್ನೂ ಏನನ್ನೂ ಪಟ್ಟಿ ಮಾಡಿಲ್ಲ." else "No listings yet.", color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
            
            ExtendedFloatingActionButton(
                onClick = { showSellDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ನನ್ನ ಬೆಳೆಯನ್ನು ಮಾರಿ" else "Sell My Crop") },
                containerColor = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SellCropDialog(selectedLanguage: AppLanguage, onDismiss: () -> Unit, onConfirm: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ನಿಮ್ಮ ಬೆಳೆಯನ್ನು ಪಟ್ಟಿ ಮಾಡಿ" else "List Your Crop", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಬೆಳೆಯ ಹೆಸರು" else "Crop Name") })
                OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಬೆಲೆ (ಪ್ರತಿ ಕ್ವಿಂಟಾಲ್)" else "Price per quintal") })
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ನಿಮ್ಮ ಸ್ಥಳ" else "Your Location") })
            }
        },
        confirmButton = {
            Button(onClick = { if (name.isNotBlank() && price.isNotBlank()) onConfirm(name, price, location) }) {
                Text(if (selectedLanguage == AppLanguage.KANNADA) "ಪಟ್ಟಿ ಮಾಡಿ" else "List Crop")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(if (selectedLanguage == AppLanguage.KANNADA) "ರದ್ದುಗೊಳಿಸಿ" else "Cancel") }
        }
    )
}

@Composable
fun MarketCard(
    selectedLanguage: AppLanguage,
    item: MarketItem,
    onMarkAsSold: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null,
    onBuy: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(if (item.isMine) 8.dp else 2.dp),
        colors = when {
            item.isSold -> CardDefaults.cardColors(containerColor = Color.LightGray.copy(alpha = 0.2f))
            item.isMine -> CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
            else -> CardDefaults.cardColors()
        }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .background(
                        when {
                            item.isSold -> Color.Gray
                            item.isMine -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                        },
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    item.name.take(1), 
                    fontSize = 24.sp, 
                    fontWeight = FontWeight.Bold, 
                    color = if (item.isMine || item.isSold) Color.White else MaterialTheme.colorScheme.primary
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.name,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = if (item.isSold) Color.Gray else Color.Unspecified
                    )
                    if (item.isMine && !item.isSold) {
                        Spacer(Modifier.width(8.dp))
                        SuggestionChip(onClick = {}, label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ನಿಮ್ಮ ಜಾಹೀರಾತು" else "Your Ad", fontSize = 10.sp) })
                    } else if (item.isSold) {
                        Spacer(Modifier.width(8.dp))
                        SuggestionChip(onClick = {}, label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಮಾರಾಟವಾಗಿದೆ" else "SOLD", fontSize = 10.sp) })
                    }
                }
                Text(item.description, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                    Text(item.location, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
            }
            
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = item.price,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (item.isSold) Color.Gray else Color(0xFF2E7D32)
                )
                if (item.isMine && !item.isSold) {
                    Row {
                        IconButton(onClick = { onMarkAsSold?.invoke() }) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Mark as Sold", tint = Color(0xFF2E7D32))
                        }
                        IconButton(onClick = { onDelete?.invoke() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color.Red)
                        }
                    }
                } else if (!item.isMine && !item.isSold) {
                    Button(
                        onClick = { onBuy?.invoke() },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                        modifier = Modifier.height(32.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(if (selectedLanguage == AppLanguage.KANNADA) "ಖರೀದಿಸಿ" else "Buy", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun WeatherScreen(selectedLanguage: AppLanguage) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2196F3))
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(if (selectedLanguage == AppLanguage.KANNADA) "ಇಂದು, ೧೪ ಮೇ" else "Today, 14 May", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Icon(Icons.Default.WbSunny, contentDescription = null, modifier = Modifier.size(80.dp), tint = Color.Yellow)
                Text("32°C", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.ExtraBold)
                Text(if (selectedLanguage == AppLanguage.KANNADA) "ಬಿಸಿಲು ಮತ್ತು ಲಘು ಗಾಳಿ" else "Sunny with light breeze", color = Color.White.copy(alpha = 0.8f))
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                    WeatherStat(Icons.Default.WaterDrop, "65%", if (selectedLanguage == AppLanguage.KANNADA) "ಆರ್ದ್ರತೆ" else "Humidity")
                    WeatherStat(Icons.Default.Air, "12 km/h", if (selectedLanguage == AppLanguage.KANNADA) "ಗಾಳಿ" else "Wind")
                    WeatherStat(Icons.Default.Cloud, "10%", if (selectedLanguage == AppLanguage.KANNADA) "ಮಳೆ" else "Precip")
                }
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(if (selectedLanguage == AppLanguage.KANNADA) "೭ ದಿನಗಳ ಮುನ್ಸೂಚನೆ" else "7-Day Forecast", modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))
        
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun").forEach { day ->
                ForecastRow(day)
            }
        }
    }
}

@Composable
fun WeatherStat(icon: androidx.compose.ui.graphics.vector.ImageVector, value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
        Text(value, color = Color.White, fontWeight = FontWeight.Bold)
        Text(label, color = Color.White.copy(alpha = 0.6f), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun ForecastRow(day: String) {
    Surface(
        color = Color.LightGray.copy(alpha = 0.1f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(day, fontWeight = FontWeight.Bold, modifier = Modifier.width(50.dp))
            Icon(Icons.Default.Cloud, contentDescription = null, tint = Color.Gray)
            Text("28° / 34°", fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun ChatListScreen() {
    val chats = listOf(
        ChatItem("Arjun Kumar", "Is the wheat still available?", "10:30 AM"),
        ChatItem("Market Admin", "Your crop listing is approved.", "Yesterday"),
        ChatItem("Suresh Raina", "I can buy 10 quintals of cotton.", "Monday"),
        ChatItem("Anita Sharma", "Need suggestions for potato farming.", "2 days ago")
    )

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(chats) { chat ->
            ListItem(
                headlineContent = { Text(chat.name, fontWeight = FontWeight.Bold) },
                supportingContent = { Text(chat.lastMessage, maxLines = 1) },
                trailingContent = { Text(chat.time, style = MaterialTheme.typography.labelSmall, color = Color.Gray) },
                leadingContent = {
                    Box(modifier = Modifier.size(48.dp).background(Color.Gray.copy(alpha = 0.2f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Person, contentDescription = null)
                    }
                },
                modifier = Modifier.clickable { /* Open Chat */ }
            )
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), thickness = 0.5.dp, color = Color.LightGray)
        }
    }
}

@Composable
fun SchemesScreen(selectedLanguage: AppLanguage) {
    val schemes = listOf(
        SchemeItem("PM-KISAN", "₹6,000 per year income support for all landholding farmers.", "ಪಿಎಂ-ಕಿಸಾನ್", "ಎಲ್ಲಾ ಭೂಹಿಡುವಳಿ ರೈತರಿಗೆ ವರ್ಷಕ್ಕೆ ₹೬,೦೦೦ ಆದಾಯ ಬೆಂಬಲ."),
        SchemeItem("PM Fasal Bima Yojana", "Crop insurance scheme for farmers at very low premium.", "ಪಿಎಂ ಫಸಲ್ ಬಿಮಾ ಯೋಜನೆ", "ಅತಿ ಕಡಿಮೆ ಪ್ರೀಮಿಯಂನಲ್ಲಿ ರೈತರಿಗೆ ಬೆಳೆ ವಿಮೆ ಯೋಜನೆ."),
        SchemeItem("Kisan Credit Card (KCC)", "Low-interest loans for agricultural needs and equipment.", "ಕಿಸಾನ್ ಕ್ರೆಡಿಟ್ ಕಾರ್ಡ್", "ಕೃಷಿ ಅಗತ್ಯತೆಗಳು ಮತ್ತು ಉಪಕರಣಗಳಿಗಾಗಿ ಕಡಿಮೆ ಬಡ್ಡಿದರದ ಸಾಲಗಳು."),
        SchemeItem("Soil Health Card", "Analyze soil quality and get fertilizer recommendations.", "ಮಣ್ಣಿನ ಆರೋಗ್ಯ ಕಾರ್ಡ್", "ಮಣ್ಣಿನ ಗುಣಮಟ್ಟವನ್ನು ವಿಶ್ಲೇಷಿಸಿ ಮತ್ತು ರಸಗೊಬ್ಬರ ಶಿಫಾರಸುಗಳನ್ನು ಪಡೆಯಿರಿ."),
        SchemeItem("Kusum Yojana", "Get 60-90% subsidy on Solar Water Pumps for irrigation.", "ಕುಸುಮ್ ಯೋಜನೆ", "ನೀರಾವರಿಗಾಗಿ ಸೌರ ನೀರಿನ ಪಂಪ್ ಗಳ ಮೇಲೆ ೬೦-೯೦% ಸಬ್ಸಿಡಿ ಪಡೆಯಿರಿ.")
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(if (selectedLanguage == AppLanguage.KANNADA) "ಸರ್ಕಾರಿ ಯೋಜನೆಗಳು" else "Govt. Schemes", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
        }
        items(schemes) { scheme ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        if (selectedLanguage == AppLanguage.KANNADA) scheme.title_kn else scheme.title, 
                        fontWeight = FontWeight.ExtraBold, 
                        style = MaterialTheme.typography.titleMedium, 
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        if (selectedLanguage == AppLanguage.KANNADA) scheme.description_kn else scheme.description, 
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(onClick = { /* Apply */ }) {
                        Text(if (selectedLanguage == AppLanguage.KANNADA) "ಈಗಲೇ ಅನ್ವಯಿಸಿ" else "Apply Now")
                        Icon(Icons.Default.ArrowForward, null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ExpensesScreen(selectedLanguage: AppLanguage) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            FinanceCard(Modifier.weight(1f), if (selectedLanguage == AppLanguage.KANNADA) "ಆದಾಯ" else "Income", "₹45,000", Color(0xFF2E7D32), Icons.Default.TrendingUp)
            FinanceCard(Modifier.weight(1f), if (selectedLanguage == AppLanguage.KANNADA) "ವೆಚ್ಚ" else "Expense", "₹12,400", Color(0xFFC62828), Icons.Default.TrendingDown)
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(if (selectedLanguage == AppLanguage.KANNADA) "ವಹಿವಾಟುಗಳು" else "Transactions", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))
        
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf(
                Transaction("Seed Purchase", "-₹2,500", "Yesterday", false),
                Transaction("Wheat Sale", "+₹15,000", "2 days ago", true),
                Transaction("Fertilizer", "-₹4,800", "5 days ago", false)
            )) { tx ->
                Surface(color = Color.LightGray.copy(alpha = 0.1f), shape = RoundedCornerShape(12.dp)) {
                    Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(tx.title, fontWeight = FontWeight.Bold)
                            Text(tx.date, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        }
                        Text(tx.amount, color = if (tx.isIncome) Color(0xFF2E7D32) else Color(0xFFC62828), fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
        
        Spacer(Modifier.weight(1f))
        
        Button(onClick = { /* Add */ }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text(if (selectedLanguage == AppLanguage.KANNADA) "ದಾಖಲೆ ಸೇರಿಸಿ" else "Add Record")
        }
    }
}

@Composable
fun FinanceCard(modifier: Modifier, label: String, amount: String, color: Color, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f))) {
        Column(modifier = Modifier.padding(16.dp)) {
            Icon(icon, null, tint = color)
            Text(label, style = MaterialTheme.typography.labelSmall)
            Text(amount, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmingCalendarScreen(selectedLanguage: AppLanguage) {
    val context = LocalContext.current
    var showAddEventDialog by remember { mutableStateOf(false) }
    
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        if (permissions[Manifest.permission.WRITE_CALENDAR] == true) {
            showAddEventDialog = true
        } else {
            Toast.makeText(context, "Calendar permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    if (showAddEventDialog) {
        AddEventDialog(
            selectedLanguage = selectedLanguage,
            onDismiss = { showAddEventDialog = false },
            onConfirm = { title, desc ->
                addEventToCalendar(context, title, desc)
                showAddEventDialog = false
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(if (selectedLanguage == AppLanguage.KANNADA) "ಕೃಷಿ ಯೋಜನೆ" else "Farming Planner", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(if (selectedLanguage == AppLanguage.KANNADA) "ನಿಮ್ಮ ಫೋನ್ ಕ್ಯಾಲೆಂಡರ್ ನೊಂದಿಗೆ ಸಿಂಕ್ರೊನೈಸ್ ಮಾಡಲಾಗಿದೆ" else "Synchronized with your phone calendar", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(if (selectedLanguage == AppLanguage.KANNADA) "ಮುಂಬರುವ ಕಾರ್ಯಗಳು" else "Upcoming Tasks", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                TaskRow("Sowing Wheat", if (selectedLanguage == AppLanguage.KANNADA) "ನಾಳೆ, ೮:೦೦ AM" else "Tomorrow, 8:00 AM")
                TaskRow("Fertilizer Application", "15 May, 10:00 AM")
            }
        }
        
        Spacer(Modifier.weight(1f))
        
        Button(
            onClick = { 
                permissionLauncher.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR))
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.AddAlert, null)
            Spacer(Modifier.width(8.dp))
            Text(if (selectedLanguage == AppLanguage.KANNADA) "ಕ್ಯಾಲೆಂಡರ್ ಗೆ ಜ್ಞಾಪನೆ ಸೇರಿಸಿ" else "Add Reminder to Calendar")
        }
    }
}

@Composable
fun TaskRow(title: String, time: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, style = MaterialTheme.typography.bodyMedium)
        Text(time, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEventDialog(selectedLanguage: AppLanguage, onDismiss: () -> Unit, onConfirm: (String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಕೃಷಿ ಜ್ಞಾಪನೆ ಸೇರಿಸಿ" else "Add Farming Reminder") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ಕಾರ್ಯದ ಹೆಸರು" else "Task Title") })
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text(if (selectedLanguage == AppLanguage.KANNADA) "ವಿವರಣೆ" else "Description") })
            }
        },
        confirmButton = {
            Button(onClick = { if (title.isNotBlank()) onConfirm(title, desc) }) {
                Text(if (selectedLanguage == AppLanguage.KANNADA) "ಕ್ಯಾಲೆಂಡರ್ ಗೆ ಸೇರಿಸಿ" else "Add to Phone Calendar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(if (selectedLanguage == AppLanguage.KANNADA) "ರದ್ದುಗೊಳಿಸಿ" else "Cancel") }
        }
    )
}

fun addEventToCalendar(context: android.content.Context, title: String, description: String) {
    val intent = Intent(Intent.ACTION_INSERT)
        .setData(CalendarContract.Events.CONTENT_URI)
        .putExtra(CalendarContract.Events.TITLE, title)
        .putExtra(CalendarContract.Events.DESCRIPTION, description)
        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, System.currentTimeMillis() + 3600000)
        .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, System.currentTimeMillis() + 7200000)
    
    context.startActivity(intent)
}

data class SchemeItem(val title: String, val description: String, val title_kn: String, val description_kn: String)
data class Transaction(val title: String, val amount: String, val date: String, val isIncome: Boolean)
data class MarketItem(
    val name: String,
    val price: String,
    val description: String,
    val location: String,
    val isMine: Boolean = false,
    val isSold: Boolean = false
)
data class ChatItem(val name: String, val lastMessage: String, val time: String)

@Composable
fun ResultCard(selectedLanguage: AppLanguage, result: AIResult) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, null, tint = Color(0xFF2E7D32))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    if (selectedLanguage == AppLanguage.KANNADA) "AI ಆರೋಗ್ಯ ವರದಿ" else "AI Health Report", 
                    style = MaterialTheme.typography.titleLarge, 
                    fontWeight = FontWeight.Bold, 
                    color = Color(0xFF2E7D32)
                )
            }
            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
            
            ResultRow(if (selectedLanguage == AppLanguage.KANNADA) "ಪತ್ತೆ" else "DETECTION", if (selectedLanguage == AppLanguage.KANNADA) result.disease_kn else result.disease, Icons.Default.Warning)
            ResultRow(if (selectedLanguage == AppLanguage.KANNADA) "ರಸಗೊಬ್ಬರ" else "FERTILIZER", if (selectedLanguage == AppLanguage.KANNADA) result.fertilizer_kn else result.fertilizer, Icons.Default.Science)
            ResultRow(if (selectedLanguage == AppLanguage.KANNADA) "ನೀರಾವರಿ" else "IRRIGATION", if (selectedLanguage == AppLanguage.KANNADA) result.waterReq_kn else result.waterReq, Icons.Default.WaterDrop)
            ResultRow(if (selectedLanguage == AppLanguage.KANNADA) "ಮಾರುಕಟ್ಟೆ" else "MARKET", if (selectedLanguage == AppLanguage.KANNADA) result.marketPrice_kn else result.marketPrice, Icons.AutoMirrored.Filled.TrendingUp)
        }
    }
}

@Composable
fun ResultRow(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(modifier = Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, modifier = Modifier.size(20.dp), tint = Color.Gray)
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            Text(value, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

data class AIResult(
    val disease: String, val fertilizer: String, val waterReq: String, val marketPrice: String,
    val disease_kn: String, val fertilizer_kn: String, val waterReq_kn: String, val marketPrice_kn: String
)

fun analyzeImage(bitmap: Bitmap, onComplete: (AIResult) -> Unit) {
    onComplete(
        AIResult(
            "Late Blight", "Copper spray", "Base only", "₹2,400",
            "ಲೇಟ್ ಬ್ಲೈಟ್ (ಬೂಜು ರೋಗ)", "ತಾಮ್ರದ ಸಿಂಪರಣೆ", "ಬುಡಕ್ಕೆ ಮಾತ್ರ ನೀರು", "₹೨,೪೦೦"
        )
    )
}

fun handleVoiceCommand(lang: AppLanguage, command: String, onSpeak: (String) -> Unit) {
    if (lang == AppLanguage.KANNADA) {
        onSpeak("ನಾನು ನಿಮಗೆ $command ಬಗ್ಗೆ ಸಹಾಯ ಮಾಡುತ್ತಿದ್ದೇನೆ")
    } else {
        onSpeak("I'm helping with $command")
    }
}

fun Modifier.size(size: androidx.compose.ui.unit.Dp): Modifier = this.width(size).height(size)
